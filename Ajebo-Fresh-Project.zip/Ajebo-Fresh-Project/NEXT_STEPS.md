# Ajebo build plan

1. Test the scene editor and WebM export on Android Chrome.
2. Add local project saving and reusable character references.
3. Add reliable MP4 export through a compatible video-processing library.
4. Package the app as an Android APK using a verified build pipeline.
5. Only investigate AI providers that have a documented free API allowance; do not use credit-based generation or embed secret API keys in the APK.
