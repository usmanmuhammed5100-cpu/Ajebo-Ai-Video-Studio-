# Ajebo AI Video Studio — Fresh Starter

This is a fresh, lightweight browser prototype for the Ajebo project.

## What works now
- Story input and scene splitting
- Scene text editing
- Upload an image for each scene
- Portrait 9:16 canvas preview
- Simple camera-style motion on uploaded images
- Device text-to-speech where supported
- WebM export where the browser supports `MediaRecorder`

## What is not connected yet
- AI image generation
- AI text-to-video generation
- MP4 encoding
- Cloud accounts, storage, or paid APIs

No OpenArt credits or paid API keys are used.

## Run it
Open `index.html` in a modern browser, or host this folder as a static website. It can be used as a starting point for a PWA. For an Android APK, this web app still needs to be wrapped in an Android project and built with an Android build environment.

## Important
This prototype does not promise unlimited AI generation. It currently makes slideshow-style videos from images the user supplies.
